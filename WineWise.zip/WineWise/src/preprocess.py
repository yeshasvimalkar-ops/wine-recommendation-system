import pandas as pd
import numpy as np

# ==========================================
# 1. LOAD DATASET
# ==========================================

df = pd.read_csv("data/WineDataset.csv")

print("Original dataset shape:", df.shape)


# ==========================================
# 2. REMOVE COMPLETELY UNNECESSARY COLUMNS
# ==========================================

# These columns are not useful for our recommendation engine
columns_to_drop = [
    "Secondary Grape Varieties",
    "Closure",
    "Unit",
    "Per bottle / case / each"
]

df = df.drop(columns=columns_to_drop, errors="ignore")


# ==========================================
# 3. CLEAN COLUMN NAMES
# ==========================================

df.columns = df.columns.str.strip()


# ==========================================
# 4. HANDLE TEXT COLUMNS
# ==========================================

text_columns = [
    "Title",
    "Description",
    "Grape",
    "Country",
    "Characteristics",
    "Type",
    "Region",
    "Style",
    "Appellation"
]

for column in text_columns:
    if column in df.columns:
        df[column] = df[column].fillna("Unknown").astype(str).str.strip()


# ==========================================
# 5. CLEAN NUMERICAL COLUMNS
# ==========================================

# Price
# Price
if "Price" in df.columns:
    # Convert price values such as "$25", "$1,200", "25 USD" etc.
    # into clean numeric values.
    df["Price"] = (
        df["Price"]
        .astype(str)
        .str.replace(",", "", regex=False)
        .str.extract(r"(\d+(?:\.\d+)?)")[0]
    )

    df["Price"] = pd.to_numeric(
        df["Price"],
        errors="coerce"
    )

    # Fill missing prices with the median price
    df["Price"] = df["Price"].fillna(
        df["Price"].median()
    )
    # ==========================================
# CONVERT PRICE FROM USD TO INR
# ==========================================

# Fixed exchange rate for this project
# This keeps our results reproducible.
USD_TO_INR = 85

df["Price_INR"] = (
    df["Price"] * USD_TO_INR
).round(0)

print("\nPrice conversion completed!")
print("USD to INR rate used:", USD_TO_INR)


# ABV
# ==========================================
# CLEAN ABV
# ==========================================

if "ABV" in df.columns:

    # Convert ABV to numeric
    df["ABV"] = pd.to_numeric(
        df["ABV"],
        errors="coerce"
    )

    # Fill missing ABV with median ABV
    df["ABV"] = df["ABV"].fillna(
        df["ABV"].median()
    )

    print("\nABV cleaning completed!")
    print("Missing ABV values:", df["ABV"].isna().sum())


# Vintage
if "Vintage" in df.columns:
    df["Vintage"] = pd.to_numeric(df["Vintage"], errors="coerce")
    df["Vintage"] = df["Vintage"].fillna(0)


# ==========================================
# 6. REMOVE DUPLICATES
# ==========================================

before_duplicates = len(df)

df = df.drop_duplicates()

after_duplicates = len(df)

print("Duplicate rows removed:", before_duplicates - after_duplicates)


# ==========================================
# 7. CREATE COMBINED TEXT FEATURE
# ==========================================

# This will later be used by our
# content-based recommendation system.

df["combined_features"] = (
    df["Grape"] + " " +
    df["Type"] + " " +
    df["Characteristics"] + " " +
    df["Style"] + " " +
    df["Country"] + " " +
    df["Region"] + " " +
    df["Description"]
)


# ==========================================
# 8. CLEAN COMBINED TEXT
# ==========================================

df["combined_features"] = (
    df["combined_features"]
    .str.lower()
    .str.replace(r"\s+", " ", regex=True)
    .str.strip()
)


# ==========================================
# 9. SAVE CLEAN DATASET
# ==========================================

output_path = "data/cleaned_wine_data.csv"

df.to_csv(output_path, index=False)


# ==========================================
# 10. DISPLAY RESULTS
# ==========================================

print("\n========== PREPROCESSING COMPLETE ==========")

print("\nFinal dataset shape:")
print(df.shape)

print("\nFinal columns:")
print(df.columns.tolist())

print("\nRemaining missing values:")
print(df.isnull().sum())

print("\nSample cleaned data:")
print(
    df[
        [
            "Title",
            "Price",
            "Grape",
            "Country",
            "Type",
            "Characteristics",
            "Style"
        ]
    ].head()
)

print("\nClean dataset saved to:")
print(output_path)

print("\n============================================")