import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# ==========================================
# 1. LOAD CLEANED DATASET
# ==========================================

DATA_PATH = "data/cleaned_wine_data.csv"

df = pd.read_csv(DATA_PATH)

print("Wine dataset loaded successfully!")
print("Number of wines:", len(df))


# ==========================================
# 2. PREPARE TEXT FEATURES
# ==========================================

df["combined_features"] = (
    df["combined_features"]
    .fillna("")
    .astype(str)
)


# ==========================================
# 3. TF-IDF VECTORIZATION
# ==========================================

vectorizer = TfidfVectorizer(
    stop_words="english",
    max_features=5000
)

tfidf_matrix = vectorizer.fit_transform(
    df["combined_features"]
)

print("TF-IDF matrix created!")
print("Matrix shape:", tfidf_matrix.shape)


# ==========================================
# 4. RECOMMENDATION FUNCTION
# ==========================================

def recommend_wines(
    wine_type=None,
    style=None,
    grape=None,
    country=None,
    characteristics=None,
    max_price_inr=None,
    top_n=5
):

    # --------------------------------------
    # Build user preference text
    # --------------------------------------

    preferences = []

    if wine_type:
        preferences.append(str(wine_type))

    if style:
        preferences.append(str(style))

    if grape:
        preferences.append(str(grape))

    if country:
        preferences.append(str(country))

    if characteristics:
        preferences.append(str(characteristics))

    user_profile = " ".join(preferences).lower()

    # --------------------------------------
    # Convert user profile into TF-IDF
    # --------------------------------------

    user_vector = vectorizer.transform(
        [user_profile]
    )

    # --------------------------------------
    # Calculate content similarity
    # --------------------------------------

    similarity_scores = cosine_similarity(
        user_vector,
        tfidf_matrix
    ).flatten()

    # --------------------------------------
    # Create results dataframe
    # --------------------------------------

    results = df.copy()

    results["similarity_score"] = similarity_scores

    # --------------------------------------
    # PRICE FILTER
    # --------------------------------------

    if max_price_inr is not None:

        results = results[
            results["Price_INR"] <= max_price_inr
        ].copy()

    # --------------------------------------
    # PRICE MATCH SCORE
    # --------------------------------------

    if max_price_inr is not None:

        results["price_score"] = (
            1 -
            abs(
                results["Price_INR"] - max_price_inr
            ) / max_price_inr
        ).clip(lower=0)

    else:

        results["price_score"] = 1.0

    # --------------------------------------
    # FINAL SCORE
    # --------------------------------------

    results["final_score"] = (
        0.80 * results["similarity_score"]
        +
        0.20 * results["price_score"]
    )

    # --------------------------------------
    # REMOVE DUPLICATE WINE TITLES
    # --------------------------------------

    results = results.drop_duplicates(
        subset=["Title"]
    )

    # --------------------------------------
    # SORT BY FINAL SCORE
    # --------------------------------------

    results = results.sort_values(
        by="final_score",
        ascending=False
    )

    # --------------------------------------
    # TOP N RECOMMENDATIONS
    # --------------------------------------

    recommendations = results.head(top_n).copy()

    recommendations["match_percentage"] = (
        recommendations["final_score"] * 100
    ).round(1)

    return recommendations[
        [
            "Title",
            "Type",
            "Grape",
            "Country",
            "Region",
            "Style",
            "Characteristics",
            "Price",
            "Price_INR",
            "ABV",
            "match_percentage"
        ]
    ]


# ==========================================
# 5. TEST WINEWISE
# ==========================================

if __name__ == "__main__":

    print("\n========================================")
    print("          WINEWISE TEST")
    print("========================================")

    recommendations = recommend_wines(
        wine_type="Red",
        style="Rich & Juicy",
        characteristics="Blackberry Vanilla",
        max_price_inr=3000,
        top_n=5
    )

    print("\nUser Preferences:")
    print("Type: Red")
    print("Style: Rich & Juicy")
    print("Characteristics: Blackberry Vanilla")
    print("Maximum Budget: ₹3,000")

    print("\nTop 5 Wine Recommendations:\n")

    if recommendations.empty:

        print("No wines found.")

    else:

        print(
            recommendations.to_string(
                index=False
            )
        )
