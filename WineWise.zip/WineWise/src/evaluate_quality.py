import pandas as pd
from recommender import recommend_wines


# ==========================================
# WINEWISE QUALITY EVALUATION
# ==========================================

print("\n==========================================")
print("     WINEWISE QUALITY EVALUATION")
print("==========================================\n")


# ==========================================
# TEST PROFILES
# ==========================================

test_cases = [

    {
        "name": "Red Wine - Budget",
        "wine_type": "Red",
        "style": "Rich & Juicy",
        "characteristics": "Blackberry Vanilla",
        "max_price_inr": 3000
    },

    {
        "name": "White Wine - Budget",
        "wine_type": "White",
        "style": "Crisp & Zesty",
        "characteristics": "Citrus Apple",
        "max_price_inr": 2000
    },

    {
        "name": "Premium Red Wine",
        "wine_type": "Red",
        "style": "Rich & Juicy",
        "characteristics": "Black Fruit Spice",
        "max_price_inr": 5000
    },

    {
        "name": "Affordable Wine",
        "wine_type": None,
        "style": None,
        "characteristics": None,
        "max_price_inr": 1500
    },

    {
        "name": "Premium Wine",
        "wine_type": None,
        "style": "Rich & Juicy",
        "characteristics": "Vanilla Black Fruit",
        "max_price_inr": 10000
    }
]


# ==========================================
# STORE EVALUATION RESULTS
# ==========================================

evaluation_results = []


# ==========================================
# RUN EACH TEST
# ==========================================

for test in test_cases:

    recommendations = recommend_wines(
        wine_type=test["wine_type"],
        style=test["style"],
        characteristics=test["characteristics"],
        max_price_inr=test["max_price_inr"],
        top_n=5
    )

    if recommendations.empty:

        evaluation_results.append({
            "Test": test["name"],
            "Recommendations": 0,
            "Type Match %": 0,
            "Style Match %": 0,
            "Budget Match %": 0,
            "Average Score": 0
        })

        continue


    # ======================================
    # TYPE MATCH
    # ======================================

    if test["wine_type"]:

        type_matches = (
            recommendations["Type"]
            .astype(str)
            .str.lower()
            ==
            str(test["wine_type"]).lower()
        )

        type_match_percentage = (
            type_matches.mean() * 100
        )

    else:

        type_match_percentage = 100


    # ======================================
    # STYLE MATCH
    # ======================================

    if test["style"]:

        style_matches = (
            recommendations["Style"]
            .astype(str)
            .str.lower()
            ==
            str(test["style"]).lower()
        )

        style_match_percentage = (
            style_matches.mean() * 100
        )

    else:

        style_match_percentage = 100


    # ======================================
    # BUDGET MATCH
    # ======================================

    budget_matches = (
        recommendations["Price_INR"]
        <=
        test["max_price_inr"]
    )

    budget_match_percentage = (
        budget_matches.mean() * 100
    )


    # ======================================
    # AVERAGE RECOMMENDATION SCORE
    # ======================================

    average_score = (
        recommendations["match_percentage"]
        .mean()
    )


    # ======================================
    # SAVE RESULTS
    # ======================================

    evaluation_results.append({

        "Test": test["name"],

        "Recommendations": len(
            recommendations
        ),

        "Type Match %": round(
            type_match_percentage,
            1
        ),

        "Style Match %": round(
            style_match_percentage,
            1
        ),

        "Budget Match %": round(
            budget_match_percentage,
            1
        ),

        "Average Score": round(
            average_score,
            1
        )
    })


# ==========================================
# DISPLAY RESULTS
# ==========================================

results_df = pd.DataFrame(
    evaluation_results
)


print("\nEvaluation Results:\n")

print(
    results_df.to_string(
        index=False
    )
)


# ==========================================
# OVERALL PERFORMANCE
# ==========================================

print("\n==========================================")
print("          OVERALL PERFORMANCE")
print("==========================================")

print(
    "Average Type Match: ",
    round(
        results_df["Type Match %"].mean(),
        1
    ),
    "%"
)

print(
    "Average Style Match:",
    round(
        results_df["Style Match %"].mean(),
        1
    ),
    "%"
)

print(
    "Average Budget Match:",
    round(
        results_df["Budget Match %"].mean(),
        1
    ),
    "%"
)

print(
    "Average Recommendation Score:",
    round(
        results_df["Average Score"].mean(),
        1
    ),
    "%"
)


print("\n==========================================")
print("       QUALITY EVALUATION COMPLETED")
print("==========================================")