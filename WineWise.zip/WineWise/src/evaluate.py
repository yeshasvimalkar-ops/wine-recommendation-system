import pandas as pd
from recommender import recommend_wines


# ==========================================
# WINEWISE RECOMMENDATION EVALUATION
# ==========================================

print("\n==========================================")
print("       WINEWISE EVALUATION")
print("==========================================\n")


# ==========================================
# TEST CASES
# ==========================================

test_cases = [

    {
        "name": "Budget Red Wine",
        "wine_type": "Red",
        "style": "Rich & Juicy",
        "characteristics": "Blackberry Vanilla",
        "max_price_inr": 3000
    },

    {
        "name": "Crisp White Wine",
        "wine_type": "White",
        "style": "Crisp & Zesty",
        "characteristics": "Citrus Apple",
        "max_price_inr": 2000
    },

    {
        "name": "Premium Red Wine",
        "wine_type": "Red",
        "style": "Rich & Juicy",
        "characteristics": "Black Fruit Spice",
        "max_price_inr": 5000
    },

    {
        "name": "Affordable Wine",
        "wine_type": None,
        "style": None,
        "characteristics": None,
        "max_price_inr": 1500
    },

    {
        "name": "Premium Wine",
        "wine_type": None,
        "style": "Rich & Juicy",
        "characteristics": "Vanilla Black Fruit",
        "max_price_inr": 10000
    }
]


# ==========================================
# RUN TESTS
# ==========================================

for i, test in enumerate(test_cases, start=1):

    print("\n------------------------------------------")
    print(f"TEST CASE {i}: {test['name']}")
    print("------------------------------------------")

    print("Wine Type:", test["wine_type"])
    print("Style:", test["style"])
    print("Characteristics:", test["characteristics"])
    print("Maximum Budget: ₹", test["max_price_inr"])

    recommendations = recommend_wines(
        wine_type=test["wine_type"],
        style=test["style"],
        characteristics=test["characteristics"],
        max_price_inr=test["max_price_inr"],
        top_n=5
    )

    if recommendations.empty:

        print("\nNo recommendations found.")

    else:

        display_columns = [
            "Title",
            "Type",
            "Style",
            "Price_INR",
            "match_percentage"
        ]

        print("\nTop Recommendations:")

        print(
            recommendations[
                display_columns
            ].to_string(index=False)
        )


# ==========================================
# END
# ==========================================

print("\n==========================================")
print("       EVALUATION COMPLETED")
print("==========================================")