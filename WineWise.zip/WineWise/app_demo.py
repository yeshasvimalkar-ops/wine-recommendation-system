from src.recommender import recommend_wines


# ============================================================
# WINEWISE
# ============================================================

print("\n==========================================")
print("              WINEWISE")
print("        Wine Recommendation System")
print("==========================================\n")


# ============================================================
# 1. WINE TYPE
# ============================================================

print("1. What type of wine would you like?\n")

print("1. Red")
print("2. White")
print("3. Rose")
print("4. Any type")

type_choice = input(
    "\nEnter your choice (1-4): "
).strip()


type_mapping = {
    "1": "Red",
    "2": "White",
    "3": "Rose",
    "4": None
}

if type_choice not in type_mapping:
    print("Invalid wine type choice.")
    exit()

wine_type = type_mapping[type_choice]


# ============================================================
# 2. TASTE
# ============================================================

print("\n2. What kind of taste do you prefer?\n")

print("1. Sweet & Fruity")
print("2. Smooth")
print("3. Rich & Full-bodied")
print("4. Spicy")
print("5. Fresh & Crisp")
print("6. Light & Elegant")
print("7. Floral & Aromatic")
print("8. Surprise Me")

taste_choice = input(
    "\nEnter your choice (1-8): "
).strip()


taste_mapping = {

    "1": {
        "name": "Sweet & Fruity",
        "styles": [
            "Soft & Fruity",
            "Ripe & Fruity",
            "Crisp & Fruity"
        ],
        "characteristics": [
            "Strawberry",
            "Raspberry",
            "Peach",
            "Tropical Fruit",
            "Red Fruit"
        ]
    },

    "2": {
        "name": "Smooth",
        "styles": [
            "Smooth & Mellow",
            "Smooth & Light"
        ],
        "characteristics": [
            "Vanilla",
            "Red Fruit",
            "Black Fruit"
        ]
    },

    "3": {
        "name": "Rich & Full-bodied",
        "styles": [
            "Savoury & Full Bodied",
            "Rich & Toasty",
            "Rich & Juicy"
        ],
        "characteristics": [
            "Black Fruit",
            "Blackberry",
            "Vanilla",
            "Spice"
        ]
    },

    "4": {
        "name": "Spicy",
        "styles": [
            "Bold & Spicy"
        ],
        "characteristics": [
            "Spice",
            "Black Fruit",
            "Vanilla"
        ]
    },

    "5": {
        "name": "Fresh & Crisp",
        "styles": [
            "Crisp & Zesty",
            "Fresh & Elegant",
            "Crisp & Fruity",
            "Light & Refreshing"
        ],
        "characteristics": [
            "Citrus Fruit",
            "Green Apple",
            "Peach"
        ]
    },

    "6": {
        "name": "Light & Elegant",
        "styles": [
            "Light & Elegant",
            "Delicate & Dry",
            "Smooth & Light"
        ],
        "characteristics": [
            "Red Fruit",
            "Strawberry",
            "Raspberry"
        ]
    },

    "7": {
        "name": "Floral & Aromatic",
        "styles": [
            "Aromatic & Floral"
        ],
        "characteristics": [
            "Floral",
            "Peach",
            "Citrus Fruit"
        ]
    },

    "8": {
        "name": "Surprise Me",
        "styles": [],
        "characteristics": []
    }
}


if taste_choice not in taste_mapping:
    print("Invalid taste choice.")
    exit()

taste = taste_mapping[taste_choice]

selected_taste = taste["name"]

style_text = " ".join(taste["styles"])

characteristic_text = " ".join(
    taste["characteristics"]
)


# ============================================================
# 3. BUDGET
# ============================================================

print("\n3. What is your maximum budget?\n")

print("1. Under ₹1,000")
print("2. ₹1,000 - ₹2,000")
print("3. ₹2,000 - ₹3,000")
print("4. ₹3,000 - ₹5,000")
print("5. ₹5,000 - ₹10,000")
print("6. ₹10,000+")

budget_choice = input(
    "\nEnter your choice (1-6): "
).strip()


budget_mapping = {
    "1": 1000,
    "2": 2000,
    "3": 3000,
    "4": 5000,
    "5": 10000,
    "6": 1000000
}

if budget_choice not in budget_mapping:
    print("Invalid budget choice.")
    exit()

max_budget = budget_mapping[budget_choice]


# ============================================================
# 4. SHOW USER PREFERENCES
# ============================================================

print("\n==========================================")
print("           YOUR PREFERENCES")
print("==========================================")

print(
    "Wine Type :",
    wine_type if wine_type else "Any"
)

print(
    "Taste     :",
    selected_taste
)

print(
    "Budget    : ₹",
    max_budget
)


# ============================================================
# 5. SEND INPUT TO RECOMMENDATION MODEL
# ============================================================

print("\nFinding the best wines for you...")


recommendations = recommend_wines(

    wine_type=wine_type,

    style=style_text,

    characteristics=characteristic_text,

    max_price_inr=max_budget,

    top_n=5
)


# ============================================================
# 6. DISPLAY RECOMMENDATIONS
# ============================================================

print("\n==========================================")
print("       TOP 5 WINE RECOMMENDATIONS")
print("==========================================\n")


if recommendations.empty:

    print("No wines were found within this budget.")

    print(
        "Try increasing your budget or "
        "choosing another taste preference."
    )

else:

    for i, (_, wine) in enumerate(
        recommendations.iterrows(),
        start=1
    ):

        print(f"Recommendation #{i}")
        print("------------------------------------------")

        print("Wine        :", wine["Title"])
        print("Type        :", wine["Type"])
        print("Grape       :", wine["Grape"])
        print("Country     :", wine["Country"])
        print("Region      :", wine["Region"])
        print("Style       :", wine["Style"])
        print("Price       : ₹", int(wine["Price_INR"]))
        print(
            "Match Score :",
            wine["match_percentage"],
            "%"
        )

        print()


print("==========================================")
print("          WINEWISE COMPLETE")
print("==========================================")