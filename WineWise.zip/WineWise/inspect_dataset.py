import pandas as pd

# Load the dataset
df = pd.read_csv("data/WineDataset.csv")

print("\n========== DATASET INFORMATION ==========")

# Number of rows and columns
print("\nShape of dataset:")
print(df.shape)

# Column names
print("\nColumn names:")
print(df.columns.tolist())

# First 5 rows
print("\nFirst 5 rows:")
print(df.head())

# Data types
print("\nData types:")
print(df.dtypes)

# Missing values
print("\nMissing values:")
print(df.isnull().sum())

# Duplicate rows
print("\nNumber of duplicate rows:")
print(df.duplicated().sum())

print("\n========== END ==========")