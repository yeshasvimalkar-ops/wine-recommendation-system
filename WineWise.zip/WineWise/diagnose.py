import pandas as pd

# Load cleaned dataset
df = pd.read_csv("data/cleaned_wine_data.csv")

print("\n========== PRICE DIAGNOSTIC ==========\n")

print("Price data type:")
print(df["Price"].dtype)

print("\nMinimum price:")
print(df["Price"].min())

print("\nMaximum price:")
print(df["Price"].max())

print("\nMedian price:")
print(df["Price"].median())

print("\nNumber of wines with price <= 3000:")
print((df["Price"] <= 3000).sum())

print("\nNumber of wines with price > 3000:")
print((df["Price"] > 3000).sum())

print("\nFirst 20 price values:")
print(df["Price"].head(20).to_list())

print("\nPrice statistics:")
print(df["Price"].describe())

print("\n======================================")